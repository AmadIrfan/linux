# Lab 12

### Name : Muhammad Uzair

### Reg No : 2021-CS-17



## Task1

####Write a program that contains 3 threads. Each thread increment the global variable and then adds that value to the result which is another global variable. Initialize result and other variable with 0. Output the final value of result and the other global variable.

## CODE

```
#include <stdio.h>
#include <pthread.h>

// Define global variables
int other_variable = 0;
int result = 0;

// Define function for each thread to run
void* increment_and_add(void* arg) {
    int i;
    for (i = 0; i < 1000000; i++) {
        other_variable++;
        result += other_variable;
    }
    return NULL;
}

int main() {
    int i;
    pthread_t threads[3];

    // Create three threads and start them
    for (i = 0; i < 3; i++) {
        pthread_create(&threads[i], NULL, increment_and_add, NULL);
    }

    // Wait for threads to finish
    for (i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);
    }

    // Print final values
    printf("Other variable: %d\n", other_variable);
    printf("Result: %d\n", result);

    return 0;
}
```

In this implementation, the array **arr** is defined as being sorted before being iterated through one by one.
We compare each element to those that come before it, moving it into the proper location as we go.
The sorted array is then printed out.


Keep in mind that this approach takes the array's elements to be integers.
You must adjust the comparison procedure appropriately if you're using an array of strings.

**Output**

![](pic1.png)



##Task2

####Write a program that creates threads based on the input given by user. Each thread should execute function print () and display its thread ID. The output should be like:                                          Hello I am thread 1 my ID is 123 Hello I am thread 2 my ID is 234.... The main thread should wait for the child threads to terminate and then call exit.Use pthread_self() pthread_t ID= pthread_self (void);Returns the unique thread ID of the calling thread

## CODE

```
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *print_thread_id(void *arg) {
    long id = (long) arg;
    printf("Hello, I am thread %ld, my ID is %lu\n", id, pthread_self());
    pthread_exit(NULL);
}

int main() {
    int num_threads;
    printf("Enter the number of threads to create: ");
    scanf("%d", &num_threads);

    pthread_t threads[num_threads];
    int i;
    for (i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, print_thread_id, (void *) (long) (i+1));
    }

    for (i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("All threads have completed. Exiting...\n");
    exit(EXIT_SUCCESS);
}
```

**Output**

![](pic2.png)

## Task3

#### Write a C program that create 4 threads with proper create, join, exit system calls and all threads are doing different jobs.

```
include <stdio.h>
include <stdlib.h>
include <pthread.h>
void *thread1(void *arg) {
printf("Thread 1 is running\n");
// do some work
printf("Thread 1 is done\n");
pthread_exit(NULL);
}
void *thread2(void *arg) {

    printf("Thread 2 is running\n");
    // do some work
    printf("Thread 2 is done\n");
    pthread_exit(NULL);

}
void *thread3(void *arg) {

    printf("Thread 3 is running\n");
    // do some work
    printf("Thread 3 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {

    printf("Thread 4 is running\n");
    // do some work
    printf("Thread 4 is done\n");
    pthread_exit(NULL);

}
void *thread4(void *arg) {
printf("Thread 4 is running\n");
// do some work
printf("Thread 4 is done\n");
pthread_exit(NULL);
}
int main() {
pthread_t threads[4];
// create threads
pthread_create(&threads[0], NULL, thread1, NULL);
pthread_create(&threads[1], NULL, thread2, NULL);
pthread_create(&threads[2], NULL, thread3, NULL);
pthread_create(&threads[3], NULL, thread4, NULL);

// wait for threads to finish
pthread_join(threads[0], NULL);
pthread_join(threads[1], NULL);
pthread_join(threads[2], NULL);
pthread_join(threads[3], NULL);

// exit program
exit(EXIT_SUCCESS);
}

```

**Output**

![](pic3.png)

## Task4

#### Write a c program that creates an array of 4 threads using for loop and return thread id and process id from each thread and comment on the IDs threads and processes.

```
include <stdio.h>
include <pthread.h>
include <unistd.h>
void *thread_func(void *arg) {
printf("Thread ID: %lu, Process ID: %d\n", pthread_self(), getpid());
return NULL;
}
int main() {

    pthread_t threads[4];
    int i;
    for (i = 0; i < 4; i++) {
        pthread_create(&threads[i], NULL, thread_func, NULL);
    }
    for (i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }
    return 0;

}


```

**Output**

![](pic4.png)